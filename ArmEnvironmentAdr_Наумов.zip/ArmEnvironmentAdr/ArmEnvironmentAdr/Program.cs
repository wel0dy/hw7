using System.Text;
using System.Text.Json;
using ArmEnvironmentAdr;

// Утилита для предпроектного аудита АРМ диспетчера освещения SmartLight IoT.
// Считывает параметры ОС и .NET, сверяет установленную версию .NET с публичными метаданными
// релизов и создает запись архитектурного решения docs\ADR-001-Environment.md.

Console.OutputEncoding = Encoding.UTF8;
const string ReleasesIndex = "https://dotnetcli.blob.core.windows.net/dotnet/release-metadata/releases-index.json";
const double MinFreeDiskGb = 2.0;
const int MinCores = 2;

EnvironmentSnapshot env = EnvironmentSnapshot.Read();
Console.WriteLine("=== Аудит среды АРМ диспетчера освещения ===");
Console.WriteLine($"Компьютер:   {env.Machine}");
Console.WriteLine($"ОС:          {env.OsDescription} ({env.Architecture})");
Console.WriteLine($"Ядра / диск: {env.Cores} шт. / свободно {env.FreeDiskGb} ГБ");
Console.WriteLine($"Платформа:   {env.Framework}");

DotnetChannel? channel = null;
string? networkError = null;
string channelName = $"{env.Runtime.Major}.{env.Runtime.Minor}";
try
{
    using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
    using JsonDocument index = JsonDocument.Parse(await http.GetStringAsync(ReleasesIndex));
    foreach (JsonElement item in index.RootElement.GetProperty("releases-index").EnumerateArray())
    {
        if (item.GetProperty("channel-version").GetString() != channelName) continue;
        channel = new DotnetChannel(channelName,
            item.GetProperty("latest-runtime").GetString() ?? "?",
            item.GetProperty("support-phase").GetString() ?? "?",
            item.TryGetProperty("eol-date", out JsonElement eol) ? eol.GetString() ?? "?" : "?");
        break;
    }
}
catch (TaskCanceledException) { networkError = "индекс релизов не ответил за 15 секунд"; }
catch (HttpRequestException ex) { networkError = "нет доступа к индексу релизов: " + ex.Message; }
catch (Exception ex) when (ex is JsonException or KeyNotFoundException) { networkError = "индекс релизов в неожиданном формате"; }

// Проверки готовности рабочего места
var checks = new List<(string Name, bool Ok, string Note)>
{
    ("64-битная ОС", env.Architecture is "X64" or "Arm64", env.Architecture),
    ($"Не менее {MinCores} ядер", env.Cores >= MinCores, env.Cores.ToString()),
    ($"Свободно не менее {MinFreeDiskGb} ГБ", env.FreeDiskGb >= MinFreeDiskGb, $"{env.FreeDiskGb} ГБ"),
    ("Ветка .NET поддерживается", channel != null && channel.SupportPhase is "active" or "maintenance",
        channel?.SupportPhase ?? networkError ?? "ветка не найдена"),
    ("Установлены последние исправления", channel != null && Version.TryParse(channel.LatestRuntime, out Version? latest)
        && env.Runtime >= latest, channel == null ? "нет данных" : $"{env.Runtime} / последняя {channel.LatestRuntime}")
};

Console.WriteLine();
foreach (var c in checks)
{
    Console.ForegroundColor = c.Ok ? ConsoleColor.Green : ConsoleColor.Yellow;
    Console.WriteLine($"{(c.Ok ? "[OK]  " : "[WARN]")} {c.Name,-36} {c.Note}");
}
Console.ResetColor();

bool ready = checks.Take(4).All(c => c.Ok);
string decision = ready
    ? "Рабочее место допускается к установке клиентского ПО SmartLight на платформе .NET " + channelName + "."
    : "Установка откладывается до устранения замечаний со статусом WARN.";

// Запись архитектурного решения в формате Markdown
var adr = new StringBuilder()
    .AppendLine("# ADR-001. Среда выполнения АРМ диспетчера освещения")
    .AppendLine()
    .AppendLine($"Статус – {(ready ? "принято" : "отложено")}  ")
    .AppendLine($"Дата – {DateTime.Now:dd.MM.yyyy HH:mm}  ")
    .AppendLine($"Рабочее место – {env.Machine}")
    .AppendLine()
    .AppendLine("## Контекст")
    .AppendLine()
    .AppendLine($"АРМ работает под {env.OsDescription} ({env.Architecture}), {env.Cores} ядер, свободно {env.FreeDiskGb} ГБ. " +
                $"Установлена платформа {env.Framework}.")
    .AppendLine(channel == null
        ? $"Сведения о ветке .NET {channelName} получить не удалось ({networkError ?? "ветка отсутствует в индексе"})."
        : $"По данным Microsoft последняя версия ветки {channel.Channel} – {channel.LatestRuntime}, фаза поддержки {channel.SupportPhase}, окончание поддержки {channel.EolDate}.")
    .AppendLine()
    .AppendLine("## Решение")
    .AppendLine()
    .AppendLine(decision)
    .AppendLine()
    .AppendLine("| Проверка | Результат | Значение |")
    .AppendLine("|---|---|---|");
foreach (var c in checks) adr.AppendLine($"| {c.Name} | {(c.Ok ? "OK" : "WARN")} | {c.Note} |");
adr.AppendLine()
   .AppendLine("## Последствия")
   .AppendLine()
   .AppendLine("Обновления безопасности .NET устанавливаются в ежемесячное окно обслуживания. За 6 месяцев до окончания поддержки ветки планируется переход на следующую LTS-версию.");

try
{
    string dir = Path.Combine(AppContext.BaseDirectory, "docs");
    Directory.CreateDirectory(dir);
    string path = Path.Combine(dir, "ADR-001-Environment.md");
    File.WriteAllText(path, adr.ToString(), Encoding.UTF8);
    Console.WriteLine($"\nРешение: {decision}");
    Console.WriteLine($"ADR сохранен: {path}");
}
catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
{
    Console.WriteLine("Не удалось сохранить ADR: " + ex.Message);
    return 2;
}
return ready ? 0 : 1;
