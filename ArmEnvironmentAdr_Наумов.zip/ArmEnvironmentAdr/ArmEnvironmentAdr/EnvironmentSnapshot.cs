using System.Runtime.InteropServices;

namespace ArmEnvironmentAdr
{
    // Параметры рабочего места, которые фиксируются в архитектурном решении
    public record EnvironmentSnapshot(
        string Machine, string OsDescription, string Architecture,
        int Cores, double FreeDiskGb, string Framework, Version Runtime)
    {
        public static EnvironmentSnapshot Read()
        {
            string root = Path.GetPathRoot(AppContext.BaseDirectory) ?? "C:\\";
            double freeGb = new DriveInfo(root).AvailableFreeSpace / 1024.0 / 1024 / 1024;
            return new EnvironmentSnapshot(
                Environment.MachineName,
                RuntimeInformation.OSDescription,
                RuntimeInformation.OSArchitecture.ToString(),
                Environment.ProcessorCount,
                Math.Round(freeGb, 1),
                RuntimeInformation.FrameworkDescription,
                Environment.Version);
        }
    }

    // Сведения о ветке .NET из публичного индекса релизов Microsoft
    public record DotnetChannel(string Channel, string LatestRuntime, string SupportPhase, string EolDate);
}
